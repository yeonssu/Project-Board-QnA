package com.qnaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QnaBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
